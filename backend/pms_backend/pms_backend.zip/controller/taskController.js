const task = require('../model/task')
exports.getTasks = (req, res, next) => {
    task.find((err, item) => {
        if (err) {
            throw err;
        }
        else {
            res.json(item);
        }
    })
};

exports.addTask = (req, res, next) => {

    let newTask = new task({
        backlogId: req.body.backlogId,
        taskId: req.body.taskId,
        name: req.body.name,
        start_At: req.body.start_At,
        end_At: req.body.end_At,
        status: req.body.status,
        priority: req.body.priority
    });

    newTask.save((err, item) => {
        if (err)
            res.json(err)

        res.json(item);

    });
};