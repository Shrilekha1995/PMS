var express=require('express');
var router=express.Router();
var checkToken=require('../auth/checkToken')

var project=require('../controller/projectController.js');
 var user=require('../controller/userController.js');
 var backlogController=require('../controller/backlogController');
 var taskController=require('../controller/taskController');

// for project
router.get('/getProjects',project.getProjects);
 router.post('/addProject',project.addProject);
 router.put('/updateProject/:id',project.updateProject);
 router.delete('/deleteProject/:id',project.deleteProject);
 router.get('/getProjects/:id',project.getProjectsById);

// for User Model
  router.get('/getusers',user.getUsers);
  router.post('/registeruser',user.registerUser);
  router.post('/login',user.loginUser);
  router.put('/updateuser/:id',user.updateUserById);
  router.delete('/deleteUser/:id',user.deleteUserById)

//for backlog model
  router.get('/getBacklogs',backlogController.getBacklogs);
  router.post('/addBacklog',backlogController.addBacklog);

  //for task model
  router.get('/getTasks',taskController.getTasks);
  router.post('/addTask',taskController.addTask);

module.exports=router;